// Viewport with placeholder part + view cube + state debugger
function ViewCube() {
  return (
    <div className="viewcube">
      <div className="vc-cube">
        <div className="vc-face vc-front">FRONT</div>
        <div className="vc-face vc-back">BACK</div>
        <div className="vc-face vc-right">RIGHT</div>
        <div className="vc-face vc-left">LEFT</div>
        <div className="vc-face vc-top">TOP</div>
        <div className="vc-face vc-bottom">BOTTOM</div>
      </div>
    </div>
  );
}

function Viewport() {
  return (
    <div className="viewport">
      <div className="vp-grid"></div>

      <div className="vp-stage">
        <svg width="640" height="420" viewBox="0 0 640 420" style={{position:'absolute', opacity: 0.5}}>
          {/* ground plane outlines */}
          <g stroke="rgba(255,255,255,0.10)" fill="rgba(255,255,255,0.025)" strokeWidth="1">
            <polygon points="120,260 480,260 560,330 200,330" />
            <polygon points="200,330 560,330 560,330 200,330" />
          </g>
          {/* axes */}
          <g strokeWidth="1.5" strokeLinecap="round">
            <line x1="380" y1="295" x2="430" y2="270" stroke="#7a8c5b"/>
            <line x1="380" y1="295" x2="430" y2="320" stroke="#a8593a"/>
            <line x1="380" y1="295" x2="380" y2="245" stroke="#3d6e94"/>
          </g>
        </svg>

        <div className="part-stage">
          <div className="part">
            <div className="corner tl"></div>
            <div className="corner tr"></div>
            <div className="corner bl"></div>
            <div className="corner br"></div>
          </div>
          <div className="part-shadow"></div>
        </div>
      </div>

      <ViewCube />
      <div className="vp-home"><window.Icon.Home /></div>

      <div className="state-debugger">
        <span className="label">State debugger</span>
        <span>edit / 003 / 1100</span>
        <span className="play-btn"><window.Icon.Play /></span>
      </div>

      <div className="build-stamp">v0.4.0-alpha · cadara.dev</div>
    </div>
  );
}

window.Viewport = Viewport;
