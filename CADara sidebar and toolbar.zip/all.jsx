
// ===== icons.jsx =====
// Minimal SVG icon set — stroke-based, 1.6 stroke width
const Icon = {
  Cube: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M12 3 4 7v10l8 4 8-4V7l-8-4Z"/>
      <path d="M4 7l8 4 8-4M12 11v10"/>
    </svg>
  ),
  Undo: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>
    </svg>
  ),
  Redo: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M15 14l5-5-5-5"/><path d="M20 9H9a5 5 0 0 0 0 10h3"/>
    </svg>
  ),
  Pencil: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 21l3-1 11-11-2-2L4 18l-1 3Z"/><path d="M14 7l3 3"/>
    </svg>
  ),
  Dots: (p) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
      <circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/>
    </svg>
  ),
  Line: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" {...p}>
      <circle cx="5" cy="19" r="1.5"/><circle cx="19" cy="5" r="1.5"/><path d="M6 18L18 6"/>
    </svg>
  ),
  Rect: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
      <rect x="4" y="6" width="16" height="12" rx="0.5"/>
    </svg>
  ),
  Circle: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
      <circle cx="12" cy="12" r="7"/>
    </svg>
  ),
  Arc: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" {...p}>
      <path d="M4 18a8 8 0 0 1 16 0"/>
    </svg>
  ),
  Polygon: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <path d="M12 3l8 5-3 9H7L4 8z"/>
    </svg>
  ),
  Spline: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" {...p}>
      <path d="M4 18C 8 18 8 6 12 6 S 16 18 20 18"/>
    </svg>
  ),
  Extrude: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <rect x="4" y="10" width="10" height="10"/>
      <path d="M4 10l4-4h10l-4 4M14 20l4-4V6"/>
    </svg>
  ),
  Revolve: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" {...p}>
      <ellipse cx="12" cy="12" rx="4" ry="8"/><path d="M12 4v16"/>
    </svg>
  ),
  Sweep: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 18C 8 18 8 6 14 6"/><rect x="12" y="3" width="6" height="6" transform="rotate(20 15 6)"/>
    </svg>
  ),
  Loft: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <rect x="3" y="14" width="7" height="6"/><rect x="14" y="5" width="7" height="6"/>
      <path d="M10 14l4-3M10 20l4-9"/>
    </svg>
  ),
  Fillet: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M4 20V10a6 6 0 0 1 6-6h10"/>
    </svg>
  ),
  Chamfer: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M4 20V12L12 4h8"/>
    </svg>
  ),
  Shell: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <rect x="4" y="4" width="16" height="16"/><rect x="8" y="8" width="8" height="8"/>
    </svg>
  ),
  Pattern: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
      <rect x="3" y="3" width="6" height="6"/><rect x="15" y="3" width="6" height="6"/>
      <rect x="3" y="15" width="6" height="6"/><rect x="15" y="15" width="6" height="6"/>
    </svg>
  ),
  Mirror: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <path d="M12 3v18"/><path d="M9 7L4 12l5 5"/><path d="M15 7l5 5-5 5"/>
    </svg>
  ),
  Boolean: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
      <circle cx="9" cy="12" r="5"/><circle cx="15" cy="12" r="5"/>
    </svg>
  ),
  Move: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M12 3v18M3 12h18M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3"/>
    </svg>
  ),
  Plane: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <path d="M3 8l9-4 9 4-9 4-9-4Z"/>
    </svg>
  ),
  Axis: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" {...p}>
      <path d="M5 19V5h14"/><path d="M5 19l3-3M19 5l-3 3"/>
    </svg>
  ),
  Check: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M5 13l4 4L19 7"/>
    </svg>
  ),
  Search: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" {...p}>
      <circle cx="11" cy="11" r="6"/><path d="M20 20l-4-4"/>
    </svg>
  ),
  Settings: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <circle cx="12" cy="12" r="2.5"/>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.1a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.1a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.1a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.1a1.65 1.65 0 0 0-1.51 1Z"/>
    </svg>
  ),
  Help: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" {...p}>
      <circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 1-1 1.7"/><circle cx="12" cy="17" r="0.6" fill="currentColor"/>
    </svg>
  ),
  Github: (p) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...p}>
      <path d="M12 2a10 10 0 0 0-3.16 19.49c.5.09.68-.22.68-.48v-1.7c-2.78.6-3.37-1.34-3.37-1.34-.45-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.61.07-.61 1 .07 1.53 1.03 1.53 1.03.89 1.53 2.34 1.09 2.91.83.09-.65.35-1.09.63-1.34-2.22-.25-4.55-1.11-4.55-4.94 0-1.09.39-1.98 1.03-2.68-.1-.25-.45-1.27.1-2.65 0 0 .84-.27 2.75 1.02A9.5 9.5 0 0 1 12 6.8c.85 0 1.71.11 2.51.34 1.91-1.29 2.75-1.02 2.75-1.02.55 1.38.2 2.4.1 2.65.64.7 1.03 1.59 1.03 2.68 0 3.84-2.34 4.69-4.57 4.94.36.31.68.92.68 1.85v2.74c0 .27.18.58.69.48A10 10 0 0 0 12 2Z"/>
    </svg>
  ),
  Eye: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>
    </svg>
  ),
  EyeOff: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 3l18 18"/><path d="M10.5 6.3A8.5 8.5 0 0 1 12 6c6.5 0 10 6 10 6a17 17 0 0 1-3.4 4.1M6.6 6.6A17 17 0 0 0 2 12s3.5 6 10 6c1.7 0 3.2-.4 4.5-1"/>
    </svg>
  ),
  Plus: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" {...p}>
      <path d="M12 5v14M5 12h14"/>
    </svg>
  ),
  Chevron: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M6 9l6 6 6-6"/>
    </svg>
  ),
  Sketch: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 21l3-1 11-11-2-2L4 18l-1 3Z"/>
    </svg>
  ),
  Feature: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/>
    </svg>
  ),
  Play: (p) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M7 5l12 7-12 7z"/></svg>
  ),
  Home: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <path d="M3 11l9-7 9 7v9a2 2 0 0 1-2 2h-4v-6h-6v6H5a2 2 0 0 1-2-2v-9z"/>
    </svg>
  ),
  Layers: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5M3 18l9 5 9-5"/>
    </svg>
  ),
  X: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" {...p}>
      <path d="M6 6l12 12M18 6L6 18"/>
    </svg>
  ),
  Bell: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M6 8a6 6 0 1 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9Z"/><path d="M10 21a2 2 0 0 0 4 0"/>
    </svg>
  ),
  File: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" {...p}>
      <path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/>
    </svg>
  ),
};
window.Icon = Icon;


// ===== toolbar.jsx =====
// Toolbar — modernized with grouping + variants
function ToolBtn({ icon, label, shortcut, active, success, disabled, hasChevron, onClick }) {
  const I = window.Icon[icon];
  const cls = [
    'tb-btn',
    active && 'is-active',
    success && 'is-success',
    disabled && 'is-disabled',
    hasChevron && 'has-chevron',
  ].filter(Boolean).join(' ');
  return (
    <button className={cls} onClick={onClick} disabled={disabled}>
      <I />
      {label && (
        <div className="tip">
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <span className="tip-title">{label}</span>
            {shortcut && <span className="tip-shortcut">{shortcut}</span>}
          </div>
        </div>
      )}
    </button>
  );
}

function Toolbar({ variant, activeTool }) {
  const cls = [
    'toolbar',
    variant === 'lifted-shelf' && 'is-lifted',
    variant === 'pill-clusters' && 'is-pill is-lifted',
    variant === 'flat-grouped' && '',
  ].filter(Boolean).join(' ');

  const Group = ({ children }) => <div className="tb-group">{children}</div>;
  const Divider = () => variant !== 'pill-clusters' ? <div className="tb-divider" /> : null;

  return (
    <div className={cls}>
      <div className="tb-logo">C</div>

      <Group>
        <ToolBtn icon="Undo" label="Undo" shortcut="⌘Z" />
        <ToolBtn icon="Redo" label="Redo" shortcut="⌘⇧Z" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Pencil" label="Sketch" shortcut="S" active={activeTool==='sketch'} />
        <ToolBtn icon="Plane" label="New Plane" hasChevron />
        <ToolBtn icon="Axis" label="New Axis" />
        <ToolBtn icon="Dots" label="More" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Line" label="Line" shortcut="L" />
        <ToolBtn icon="Rect" label="Rectangle" shortcut="R" />
        <ToolBtn icon="Circle" label="Circle" shortcut="C" />
        <ToolBtn icon="Arc" label="Arc" shortcut="A" />
        <ToolBtn icon="Polygon" label="Polygon" />
        <ToolBtn icon="Spline" label="Spline" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Extrude" label="Extrude" shortcut="E" hasChevron />
        <ToolBtn icon="Revolve" label="Revolve" hasChevron />
        <ToolBtn icon="Sweep" label="Sweep" />
        <ToolBtn icon="Loft" label="Loft" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Fillet" label="Fillet" shortcut="F" />
        <ToolBtn icon="Chamfer" label="Chamfer" />
        <ToolBtn icon="Shell" label="Shell" />
        <ToolBtn icon="Boolean" label="Boolean" hasChevron />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Pattern" label="Pattern" hasChevron />
        <ToolBtn icon="Mirror" label="Mirror" />
        <ToolBtn icon="Move" label="Move / Transform" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Check" label="Finish Sketch" shortcut="↵" success />
      </Group>

      <div className="tb-spacer" />

      <div className="tb-search">
        <window.Icon.Search />
        <input placeholder="Search tools…" />
        <span className="kbd">/</span>
      </div>

      <div className="tb-right">
        <button className="tb-iconbtn" title="Notifications"><window.Icon.Bell /></button>
        <button className="tb-iconbtn" title="Settings"><window.Icon.Settings /></button>
        <button className="tb-iconbtn" title="Help"><window.Icon.Help /></button>
        <button className="tb-iconbtn" title="GitHub"><window.Icon.Github /></button>
      </div>
    </div>
  );
}

window.Toolbar = Toolbar;


// ===== sidebar.jsx =====
// Sidebar — Parts & Objects, Variables, Diagnostics
const { useState } = React;

function SbHeader({ label, collapsed, onClick }) {
  return (
    <div className={'sb-header' + (collapsed ? ' is-collapsed' : '')} onClick={onClick}>
      <span>{label}</span>
      <span className="chev"><window.Icon.Chevron /></span>
    </div>
  );
}

function SbRow({ icon, label, active, hidden, onSelect, onToggleVisible, dim }) {
  const I = window.Icon[icon];
  return (
    <div
      className={['sb-row', active && 'is-active', hidden && 'is-hidden'].filter(Boolean).join(' ')}
      onClick={onSelect}
      style={dim ? { opacity: 0.55 } : undefined}
    >
      <span className="sb-icon"><I /></span>
      <span className="sb-label">{label}</span>
      <span className="sb-trail">
        <button className="sb-trail-btn" onClick={(e) => { e.stopPropagation(); onToggleVisible && onToggleVisible(); }}>
          {hidden ? <window.Icon.EyeOff /> : <window.Icon.Eye />}
        </button>
      </span>
    </div>
  );
}

function VarRow({ name, expr, value, ok }) {
  return (
    <div className="var-row">
      <span className="var-name">{name}</span>
      <span className="var-rhs">
        <span className="chip">{expr}</span>
        <span className="chip eq">=</span>
        <span className={'chip ' + (ok ? 'ok' : 'err')}>{value}</span>
      </span>
    </div>
  );
}

function Sidebar({ variant }) {
  const [collapsed, setCollapsed] = useState({ parts:false, vars:false, diag:false });
  const [active, setActive] = useState('feature_extrude-1');
  const [hidden, setHidden] = useState({ 'sketch-Draft': true });

  const cls = ['sidebar', variant === 'rail' && 'is-rail'].filter(Boolean).join(' ');
  const sectionCls = (extra='') => {
    if (variant === 'inset-shelf') return 'sb-section is-shelf ' + extra;
    if (variant === 'rule-divided') return 'sb-section is-ruled ' + extra;
    return 'sb-section ' + extra;
  };

  const items = [
    { id: 'plane-top', icon: 'Plane', label: 'Top Plane' },
    { id: 'plane-right', icon: 'Plane', label: 'Right Plane' },
    { id: 'plane-front', icon: 'Plane', label: 'Front Plane' },
    { id: 'sketch-Draft', icon: 'Sketch', label: 'sketch-Draft' },
    { id: 'feature_extrude-1', icon: 'Feature', label: 'feature_extrude-1' },
  ];

  const toggle = (k) => setCollapsed((c) => ({ ...c, [k]: !c[k] }));
  const toggleHidden = (id) => setHidden((h) => ({ ...h, [id]: !h[id] }));

  return (
    <aside className={cls}>
      <div className={sectionCls()}>
        <SbHeader label="Parts & Objects" collapsed={collapsed.parts} onClick={() => toggle('parts')} />
        {!collapsed.parts && items.map((it) => (
          <SbRow
            key={it.id}
            icon={it.icon}
            label={it.label}
            active={active === it.id}
            hidden={!!hidden[it.id]}
            onSelect={() => setActive(it.id)}
            onToggleVisible={() => toggleHidden(it.id)}
          />
        ))}
      </div>

      <div className={sectionCls()}>
        <SbHeader label="Variables" collapsed={collapsed.vars} onClick={() => toggle('vars')} />
        {!collapsed.vars && (
          <>
            <VarRow name="var1" expr="5" value="5" ok />
            <div className="add-row"><window.Icon.Plus />Add variable</div>
          </>
        )}
      </div>

      <div className={sectionCls()}>
        <SbHeader label="Document Diagnostics" collapsed={collapsed.diag} onClick={() => toggle('diag')} />
        {!collapsed.diag && (
          <div className="empty-note">No diagnostics</div>
        )}
      </div>
    </aside>
  );
}

window.Sidebar = Sidebar;


// ===== tabbar.jsx =====
// Bottom file/workspace tab bar
const { useState: useTabState } = React;

function TabBar({ variant }) {
  const [active, setActive] = useState('workspace');
  const tabs = [
    { id: 'workspace', label: 'Workspace' },
    { id: 'bracket', label: 'bracket-v3.cdr' },
    { id: 'enclosure', label: 'enclosure.cdr' },
  ];

  const cls = ['tabbar',
    variant === 'chip-row' && 'is-chip',
    variant === 'underline' && 'is-underline',
    variant === 'shelf' && 'is-shelf',
  ].filter(Boolean).join(' ');

  return (
    <div className={cls}>
      {tabs.map((t) => (
        <div
          key={t.id}
          className={'tab' + (active === t.id ? ' is-active' : '')}
          onClick={() => setActive(t.id)}
        >
          <span className="dot"></span>
          <span>{t.label}</span>
          {variant === 'shelf' && t.id !== 'workspace' && (
            <span className="close" onClick={(e) => e.stopPropagation()}><window.Icon.X /></span>
          )}
        </div>
      ))}
      <div className="tab-add"><window.Icon.Plus /></div>
      <div className="tab-meta">
        <span>0.4.0-alpha · main</span>
        <span>autosaved · 12s ago</span>
      </div>
    </div>
  );
}

window.TabBar = TabBar;


// ===== viewport.jsx =====
// Viewport with placeholder part + view cube + state debugger
function ViewCube() {
  return (
    <div className="viewcube">
      <div className="vc-cube">
        <div className="vc-face vc-front">FRONT</div>
        <div className="vc-face vc-back">BACK</div>
        <div className="vc-face vc-right">RIGHT</div>
        <div className="vc-face vc-left">LEFT</div>
        <div className="vc-face vc-top">TOP</div>
        <div className="vc-face vc-bottom">BOTTOM</div>
      </div>
    </div>
  );
}

function Viewport() {
  return (
    <div className="viewport">
      <div className="vp-grid"></div>

      <div className="vp-stage">
        <svg width="640" height="420" viewBox="0 0 640 420" style={{position:'absolute', opacity: 0.5}}>
          {/* ground plane outlines */}
          <g stroke="rgba(255,255,255,0.10)" fill="rgba(255,255,255,0.025)" strokeWidth="1">
            <polygon points="120,260 480,260 560,330 200,330" />
            <polygon points="200,330 560,330 560,330 200,330" />
          </g>
          {/* axes */}
          <g strokeWidth="1.5" strokeLinecap="round">
            <line x1="380" y1="295" x2="430" y2="270" stroke="#7a8c5b"/>
            <line x1="380" y1="295" x2="430" y2="320" stroke="#a8593a"/>
            <line x1="380" y1="295" x2="380" y2="245" stroke="#3d6e94"/>
          </g>
        </svg>

        <div className="part-stage">
          <div className="part">
            <div className="corner tl"></div>
            <div className="corner tr"></div>
            <div className="corner bl"></div>
            <div className="corner br"></div>
          </div>
          <div className="part-shadow"></div>
        </div>
      </div>

      <ViewCube />
      <div className="vp-home"><window.Icon.Home /></div>

      <div className="state-debugger">
        <span className="label">State debugger</span>
        <span>edit / 003 / 1100</span>
        <span className="play-btn"><window.Icon.Play /></span>
      </div>

      <div className="build-stamp">v0.4.0-alpha · cadara.dev</div>
    </div>
  );
}

window.Viewport = Viewport;


// ===== app.jsx =====
const { useState: useAppState } = React;

function HistoryBar() {
  return (
    <div className="history-wrap">
      <div className="history">
        <div className="h-step sketch">
          <window.Icon.Sketch />
          <span>Sketch-Draft</span>
        </div>
        <div className="h-step feature is-active">
          <window.Icon.Feature />
          <span>Extrude 1</span>
        </div>
      </div>
      <div className="h-scrubber">
        <div className="track">
          <div className="thumb"></div>
        </div>
      </div>
    </div>
  );
}

function App() {
  const defaults = window.__TWEAK_DEFAULTS;
  const [tweaks, setTweak] = window.useTweaks(defaults);

  const {
    TweaksPanel, TweakSection, TweakRadio, TweakSelect, TweakToggle,
  } = window;

  return (
    <div className="app">
      <window.Toolbar variant={tweaks.toolbarVariant} activeTool={tweaks.showActiveTool ? 'sketch' : null} />
      <div className="app-body">
        <window.Sidebar variant={tweaks.sidebarVariant} />
        <div style={{ position: 'relative', height: '100%', overflow: 'hidden' }}>
          <window.Viewport />
          <HistoryBar />
          <window.TabBar variant={tweaks.tabbarVariant} />
        </div>
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Toolbar">
          <TweakRadio
            label="Style"
            value={tweaks.toolbarVariant}
            onChange={(v) => setTweak('toolbarVariant', v)}
            options={[
              { value: 'flat-grouped', label: 'Flat + dividers' },
              { value: 'lifted-shelf', label: 'Lifted shelf' },
              { value: 'pill-clusters', label: 'Pill clusters' },
            ]}
          />
          <TweakToggle
            label="Show active tool state"
            value={tweaks.showActiveTool}
            onChange={(v) => setTweak('showActiveTool', v)}
          />
        </TweakSection>

        <TweakSection title="Sidebar">
          <TweakRadio
            label="Style"
            value={tweaks.sidebarVariant}
            onChange={(v) => setTweak('sidebarVariant', v)}
            options={[
              { value: 'flush', label: 'Flush' },
              { value: 'rule-divided', label: 'Hairline rules' },
              { value: 'inset-shelf', label: 'Inset shelves' },
              { value: 'rail', label: 'Selection rail' },
            ]}
          />
        </TweakSection>

        <TweakSection title="File tabs">
          <TweakRadio
            label="Style"
            value={tweaks.tabbarVariant}
            onChange={(v) => setTweak('tabbarVariant', v)}
            options={[
              { value: 'shelf', label: 'Shelf chips' },
              { value: 'chip-row', label: 'Floating chips' },
              { value: 'underline', label: 'Underline' },
            ]}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);

