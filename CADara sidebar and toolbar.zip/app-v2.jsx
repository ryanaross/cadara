// app-v2.jsx — floating toolbar + floating tree + variables FAB
const { useState: useAppStateV2 } = React;

function FloatingPartsTree() {
  const [active, setActive] = React.useState('feature_extrude-1');
  const [hidden, setHidden] = React.useState({ 'sketch-Draft': true });
  const items = [
    { id: 'plane-top', icon: 'Plane', label: 'Top Plane' },
    { id: 'plane-right', icon: 'Plane', label: 'Right Plane' },
    { id: 'plane-front', icon: 'Plane', label: 'Front Plane' },
    { id: 'sketch-Draft', icon: 'Sketch', label: 'sketch-Draft' },
    { id: 'feature_extrude-1', icon: 'Feature', label: 'feature_extrude-1' },
  ];
  const toggleHidden = (id) => setHidden((h) => ({ ...h, [id]: !h[id] }));
  return (
    <div className="parts-tree">
      <div className="pt-header">Parts &amp; Objects</div>
      {items.map((it) => {
        const I = window.Icon[it.icon];
        const isHidden = !!hidden[it.id];
        return (
          <div
            key={it.id}
            className={['pt-row', active === it.id && 'is-active', isHidden && 'is-hidden'].filter(Boolean).join(' ')}
            onClick={() => setActive(it.id)}
          >
            <span className="pt-icon"><I /></span>
            <span>{it.label}</span>
            <span className="pt-trail" onClick={(e) => { e.stopPropagation(); toggleHidden(it.id); }}>
              {isHidden ? <window.Icon.EyeOff /> : <window.Icon.Eye />}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function VariablesPanel({ onClose }) {
  return (
    <div className="vars-panel">
      <div className="vp-head">
        <span className="vp-title">Variables</span>
        <span className="vp-close" onClick={onClose}><window.Icon.X /></span>
      </div>
      <div className="vp-body">
        <div className="var-row">
          <span className="var-name">var1</span>
          <span className="var-rhs">
            <span className="chip">5</span>
            <span className="chip eq">=</span>
            <span className="chip ok">5</span>
          </span>
        </div>
        <div className="var-row">
          <span className="var-name">thickness</span>
          <span className="var-rhs">
            <span className="chip">var1 * 0.4</span>
            <span className="chip eq">=</span>
            <span className="chip ok">2</span>
          </span>
        </div>
        <div className="add-row"><window.Icon.Plus />Add variable</div>
      </div>
    </div>
  );
}

function HistoryBarV2() {
  return (
    <div className="history-wrap">
      <div className="history">
        <div className="h-step sketch">
          <window.Icon.Sketch />
          <span>Sketch-Draft</span>
        </div>
        <div className="h-step feature is-active">
          <window.Icon.Feature />
          <span>Extrude 1</span>
        </div>
      </div>
      <div className="h-scrubber">
        <div className="track">
          <div className="thumb"></div>
        </div>
      </div>
    </div>
  );
}

function VarsFAB({ open, onClick }) {
  return (
    <button
      className={'vars-fab' + (open ? ' is-open' : '')}
      onClick={onClick}
      title={open ? 'Close variables' : 'Variables'}
    >
      {open ? <window.Icon.X /> : <window.Icon.Layers />}
    </button>
  );
}

function AppV2() {
  const defaults = window.__TWEAK_DEFAULTS;
  const [tweaks, setTweak] = window.useTweaks(defaults);
  const [varsOpen, setVarsOpen] = React.useState(false);

  const { TweaksPanel, TweakSection, TweakRadio } = window;

  return (
    <div className="app">
      {/* Fullscreen viewport, no sidebar */}
      <div style={{ position: 'absolute', inset: 0 }}>
        <window.Viewport />
        <FloatingPartsTree />
        <HistoryBarV2 />
        <window.TabBar variant={tweaks.tabbarVariant} />
      </div>

      {/* Floating toolbar over viewport */}
      <window.Toolbar variant="pill-clusters" activeTool={tweaks.showActiveTool ? 'sketch' : null} />

      {/* Variables panel + FAB */}
      {varsOpen && <VariablesPanel onClose={() => setVarsOpen(false)} />}
      <VarsFAB open={varsOpen} onClick={() => setVarsOpen((v) => !v)} />

      <TweaksPanel title="Tweaks">
        <TweakSection title="File tabs">
          <TweakRadio
            label="Style"
            value={tweaks.tabbarVariant}
            onChange={(v) => setTweak('tabbarVariant', v)}
            options={[
              { value: 'shelf', label: 'Shelf chips' },
              { value: 'chip-row', label: 'Floating chips' },
              { value: 'underline', label: 'Underline' },
            ]}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

const rootV2 = ReactDOM.createRoot(document.getElementById('root'));
rootV2.render(<AppV2 />);
