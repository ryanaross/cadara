// Bottom file/workspace tab bar
const { useState: useTabState } = React;

function TabBar({ variant }) {
  const [active, setActive] = useState('workspace');
  const tabs = [
    { id: 'workspace', label: 'Workspace' },
    { id: 'bracket', label: 'bracket-v3.cdr' },
    { id: 'enclosure', label: 'enclosure.cdr' },
  ];

  const cls = ['tabbar',
    variant === 'chip-row' && 'is-chip',
    variant === 'underline' && 'is-underline',
    variant === 'shelf' && 'is-shelf',
  ].filter(Boolean).join(' ');

  return (
    <div className={cls}>
      {tabs.map((t) => (
        <div
          key={t.id}
          className={'tab' + (active === t.id ? ' is-active' : '')}
          onClick={() => setActive(t.id)}
        >
          <span className="dot"></span>
          <span>{t.label}</span>
          {variant === 'shelf' && t.id !== 'workspace' && (
            <span className="close" onClick={(e) => e.stopPropagation()}><window.Icon.X /></span>
          )}
        </div>
      ))}
      <div className="tab-add"><window.Icon.Plus /></div>
      <div className="tab-meta">
        <span>0.4.0-alpha · main</span>
        <span>autosaved · 12s ago</span>
      </div>
    </div>
  );
}

window.TabBar = TabBar;
