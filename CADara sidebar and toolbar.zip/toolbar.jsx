// Toolbar — modernized with grouping + variants
function ToolBtn({ icon, label, shortcut, active, success, disabled, hasChevron, onClick }) {
  const I = window.Icon[icon];
  const cls = [
    'tb-btn',
    active && 'is-active',
    success && 'is-success',
    disabled && 'is-disabled',
    hasChevron && 'has-chevron',
  ].filter(Boolean).join(' ');
  return (
    <button className={cls} onClick={onClick} disabled={disabled}>
      <I />
      {label && (
        <div className="tip">
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <span className="tip-title">{label}</span>
            {shortcut && <span className="tip-shortcut">{shortcut}</span>}
          </div>
        </div>
      )}
    </button>
  );
}

function Toolbar({ variant, activeTool }) {
  const cls = [
    'toolbar',
    variant === 'lifted-shelf' && 'is-lifted',
    variant === 'pill-clusters' && 'is-pill is-lifted',
    variant === 'flat-grouped' && '',
  ].filter(Boolean).join(' ');

  const Group = ({ children }) => <div className="tb-group">{children}</div>;
  const Divider = () => variant !== 'pill-clusters' ? <div className="tb-divider" /> : null;

  return (
    <div className={cls}>
      <div className="tb-logo">C</div>

      <Group>
        <ToolBtn icon="Undo" label="Undo" shortcut="⌘Z" />
        <ToolBtn icon="Redo" label="Redo" shortcut="⌘⇧Z" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Pencil" label="Sketch" shortcut="S" active={activeTool==='sketch'} />
        <ToolBtn icon="Plane" label="New Plane" hasChevron />
        <ToolBtn icon="Axis" label="New Axis" />
        <ToolBtn icon="Dots" label="More" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Line" label="Line" shortcut="L" />
        <ToolBtn icon="Rect" label="Rectangle" shortcut="R" />
        <ToolBtn icon="Circle" label="Circle" shortcut="C" />
        <ToolBtn icon="Arc" label="Arc" shortcut="A" />
        <ToolBtn icon="Polygon" label="Polygon" />
        <ToolBtn icon="Spline" label="Spline" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Extrude" label="Extrude" shortcut="E" hasChevron />
        <ToolBtn icon="Revolve" label="Revolve" hasChevron />
        <ToolBtn icon="Sweep" label="Sweep" />
        <ToolBtn icon="Loft" label="Loft" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Fillet" label="Fillet" shortcut="F" />
        <ToolBtn icon="Chamfer" label="Chamfer" />
        <ToolBtn icon="Shell" label="Shell" />
        <ToolBtn icon="Boolean" label="Boolean" hasChevron />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Pattern" label="Pattern" hasChevron />
        <ToolBtn icon="Mirror" label="Mirror" />
        <ToolBtn icon="Move" label="Move / Transform" />
      </Group>
      <Divider />

      <Group>
        <ToolBtn icon="Check" label="Finish Sketch" shortcut="↵" success />
      </Group>

      <div className="tb-spacer" />

      <div className="tb-search">
        <window.Icon.Search />
        <input placeholder="Search tools…" />
        <span className="kbd">/</span>
      </div>

      <div className="tb-right">
        <button className="tb-iconbtn" title="Notifications"><window.Icon.Bell /></button>
        <button className="tb-iconbtn" title="Settings"><window.Icon.Settings /></button>
        <button className="tb-iconbtn" title="Help"><window.Icon.Help /></button>
        <button className="tb-iconbtn" title="GitHub"><window.Icon.Github /></button>
      </div>
    </div>
  );
}

window.Toolbar = Toolbar;
