const { useState: useAppState } = React;

function HistoryBar() {
  return (
    <div className="history-wrap">
      <div className="history">
        <div className="h-step sketch">
          <window.Icon.Sketch />
          <span>Sketch-Draft</span>
        </div>
        <div className="h-step feature is-active">
          <window.Icon.Feature />
          <span>Extrude 1</span>
        </div>
      </div>
      <div className="h-scrubber">
        <div className="track">
          <div className="thumb"></div>
        </div>
      </div>
    </div>
  );
}

function App() {
  const defaults = window.__TWEAK_DEFAULTS;
  const [tweaks, setTweak] = window.useTweaks(defaults);

  const {
    TweaksPanel, TweakSection, TweakRadio, TweakSelect, TweakToggle,
  } = window;

  return (
    <div className="app">
      <window.Toolbar variant={tweaks.toolbarVariant} activeTool={tweaks.showActiveTool ? 'sketch' : null} />
      <div className="app-body">
        <window.Sidebar variant={tweaks.sidebarVariant} />
        <div style={{ position: 'relative', height: '100%', overflow: 'hidden' }}>
          <window.Viewport />
          <HistoryBar />
          <window.TabBar variant={tweaks.tabbarVariant} />
        </div>
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Toolbar">
          <TweakRadio
            label="Style"
            value={tweaks.toolbarVariant}
            onChange={(v) => setTweak('toolbarVariant', v)}
            options={[
              { value: 'flat-grouped', label: 'Flat + dividers' },
              { value: 'lifted-shelf', label: 'Lifted shelf' },
              { value: 'pill-clusters', label: 'Pill clusters' },
            ]}
          />
          <TweakToggle
            label="Show active tool state"
            value={tweaks.showActiveTool}
            onChange={(v) => setTweak('showActiveTool', v)}
          />
        </TweakSection>

        <TweakSection title="Sidebar">
          <TweakRadio
            label="Style"
            value={tweaks.sidebarVariant}
            onChange={(v) => setTweak('sidebarVariant', v)}
            options={[
              { value: 'flush', label: 'Flush' },
              { value: 'rule-divided', label: 'Hairline rules' },
              { value: 'inset-shelf', label: 'Inset shelves' },
              { value: 'rail', label: 'Selection rail' },
            ]}
          />
        </TweakSection>

        <TweakSection title="File tabs">
          <TweakRadio
            label="Style"
            value={tweaks.tabbarVariant}
            onChange={(v) => setTweak('tabbarVariant', v)}
            options={[
              { value: 'shelf', label: 'Shelf chips' },
              { value: 'chip-row', label: 'Floating chips' },
              { value: 'underline', label: 'Underline' },
            ]}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
