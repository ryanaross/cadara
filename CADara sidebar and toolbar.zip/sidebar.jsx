// Sidebar — Parts & Objects, Variables, Diagnostics
const { useState } = React;

function SbHeader({ label, collapsed, onClick }) {
  return (
    <div className={'sb-header' + (collapsed ? ' is-collapsed' : '')} onClick={onClick}>
      <span>{label}</span>
      <span className="chev"><window.Icon.Chevron /></span>
    </div>
  );
}

function SbRow({ icon, label, active, hidden, onSelect, onToggleVisible, dim }) {
  const I = window.Icon[icon];
  return (
    <div
      className={['sb-row', active && 'is-active', hidden && 'is-hidden'].filter(Boolean).join(' ')}
      onClick={onSelect}
      style={dim ? { opacity: 0.55 } : undefined}
    >
      <span className="sb-icon"><I /></span>
      <span className="sb-label">{label}</span>
      <span className="sb-trail">
        <button className="sb-trail-btn" onClick={(e) => { e.stopPropagation(); onToggleVisible && onToggleVisible(); }}>
          {hidden ? <window.Icon.EyeOff /> : <window.Icon.Eye />}
        </button>
      </span>
    </div>
  );
}

function VarRow({ name, expr, value, ok }) {
  return (
    <div className="var-row">
      <span className="var-name">{name}</span>
      <span className="var-rhs">
        <span className="chip">{expr}</span>
        <span className="chip eq">=</span>
        <span className={'chip ' + (ok ? 'ok' : 'err')}>{value}</span>
      </span>
    </div>
  );
}

function Sidebar({ variant }) {
  const [collapsed, setCollapsed] = useState({ parts:false, vars:false, diag:false });
  const [active, setActive] = useState('feature_extrude-1');
  const [hidden, setHidden] = useState({ 'sketch-Draft': true });

  const cls = ['sidebar', variant === 'rail' && 'is-rail'].filter(Boolean).join(' ');
  const sectionCls = (extra='') => {
    if (variant === 'inset-shelf') return 'sb-section is-shelf ' + extra;
    if (variant === 'rule-divided') return 'sb-section is-ruled ' + extra;
    return 'sb-section ' + extra;
  };

  const items = [
    { id: 'plane-top', icon: 'Plane', label: 'Top Plane' },
    { id: 'plane-right', icon: 'Plane', label: 'Right Plane' },
    { id: 'plane-front', icon: 'Plane', label: 'Front Plane' },
    { id: 'sketch-Draft', icon: 'Sketch', label: 'sketch-Draft' },
    { id: 'feature_extrude-1', icon: 'Feature', label: 'feature_extrude-1' },
  ];

  const toggle = (k) => setCollapsed((c) => ({ ...c, [k]: !c[k] }));
  const toggleHidden = (id) => setHidden((h) => ({ ...h, [id]: !h[id] }));

  return (
    <aside className={cls}>
      <div className={sectionCls()}>
        <SbHeader label="Parts & Objects" collapsed={collapsed.parts} onClick={() => toggle('parts')} />
        {!collapsed.parts && items.map((it) => (
          <SbRow
            key={it.id}
            icon={it.icon}
            label={it.label}
            active={active === it.id}
            hidden={!!hidden[it.id]}
            onSelect={() => setActive(it.id)}
            onToggleVisible={() => toggleHidden(it.id)}
          />
        ))}
      </div>

      <div className={sectionCls()}>
        <SbHeader label="Variables" collapsed={collapsed.vars} onClick={() => toggle('vars')} />
        {!collapsed.vars && (
          <>
            <VarRow name="var1" expr="5" value="5" ok />
            <div className="add-row"><window.Icon.Plus />Add variable</div>
          </>
        )}
      </div>

      <div className={sectionCls()}>
        <SbHeader label="Document Diagnostics" collapsed={collapsed.diag} onClick={() => toggle('diag')} />
        {!collapsed.diag && (
          <div className="empty-note">No diagnostics</div>
        )}
      </div>
    </aside>
  );
}

window.Sidebar = Sidebar;
